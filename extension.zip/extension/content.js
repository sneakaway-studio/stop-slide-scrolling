


    console.log("Stop Slide Scrolling in Google Presentation loaded")

    window.addEventListener("mousewheel", function (event) {
        event.stopPropagation();
    }, true);
